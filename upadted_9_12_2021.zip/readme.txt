Contains the page for death certificate register.

The death certificate register page has only been added in the repository, 
but not has been integrated into the application.

The death certificate register portal had not been connected to any database,
it has not been integrated with the controller in the NodeJS file.

------------------ update 17/11/2021, 11:32 hrs.------------------------------------------------------------------------------------------
the death certificate registration section has been integrated with the backend, middleware
and the database has been connected properly with this section.
-By: Subhodeep Moitra
------------------------------------------------------------------------------------------------------------------------------------------------------------------


